
package ui;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import model.Student;


public class configs {
    
    public ArrayList<Student> readConfig() {
        String thisLine = "";
    
       ArrayList<Student> list=new ArrayList<>();

        try {

            BufferedReader br = new BufferedReader(new FileReader("config.txt"));
            thisLine = br.readLine();
            
            while (thisLine != null) {
              
                Student student = new Student();
                String read[] = thisLine.split("\\,");
                student.setStudentName(read[0]);
                student.setCourse(read[1]);
                student.setGpa(read[2]);
                student.setAttempts(Integer.parseInt(read[3])); 
                student.setAreaOfInterest(read[4]);
                list.add(student);
                thisLine = br.readLine();
            }
           
            return list;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }
    
    
}
